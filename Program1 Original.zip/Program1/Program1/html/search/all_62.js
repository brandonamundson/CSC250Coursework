var searchData=
[
  ['birthdate',['birthDate',['../struct_record.html#a637320129038cc47435c5b155a8fdd65',1,'Record']]]
];
