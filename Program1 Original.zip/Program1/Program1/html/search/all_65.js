var searchData=
[
  ['errorcheck',['errorCheck',['../functions_8h.html#aa1bc9937c29c40f398d36181f23268da',1,'errorCheck(string &amp;countFalse, ofstream &amp;good, ofstream &amp;bad, Record record):&#160;functons.cpp'],['../functons_8cpp.html#aa1bc9937c29c40f398d36181f23268da',1,'errorCheck(string &amp;countFalse, ofstream &amp;good, ofstream &amp;bad, Record record):&#160;functons.cpp']]],
  ['expirationdate',['expirationDate',['../struct_record.html#add079d03e92fb4e5563176012a42b3d0',1,'Record']]],
  ['extractdate',['extractDate',['../functions_8h.html#afaded059d76cc481053d3d5f40cba706',1,'extractDate(unsigned int date, string &amp;countFalse, int &amp;i, string &amp;format):&#160;functons.cpp'],['../functons_8cpp.html#afaded059d76cc481053d3d5f40cba706',1,'extractDate(unsigned int date, string &amp;countFalse, int &amp;i, string &amp;format):&#160;functons.cpp']]]
];
