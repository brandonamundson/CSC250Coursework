var searchData=
[
  ['radioclass',['radioClass',['../struct_record.html#a42e79987752633e9499ed15383ced531',1,'Record']]],
  ['record',['Record',['../struct_record.html',1,'']]]
];
