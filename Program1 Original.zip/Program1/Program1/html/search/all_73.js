var searchData=
[
  ['sign',['sign',['../functions_8h.html#a31f175e8d7c4a913a251735b7bec3bdf',1,'sign(string sign, string &amp;countFalse):&#160;functons.cpp'],['../functons_8cpp.html#a31f175e8d7c4a913a251735b7bec3bdf',1,'sign(string sign, string &amp;countFalse):&#160;functons.cpp']]],
  ['state',['state',['../struct_record.html#acfebf41340d22affb2ec1e90442e514f',1,'Record::state()'],['../functions_8h.html#ae94b3a805b26d01bda557f0ea686ff30',1,'state(string state, string &amp;countFalse):&#160;functons.cpp'],['../functons_8cpp.html#ae94b3a805b26d01bda557f0ea686ff30',1,'state(string state, string &amp;countFalse):&#160;functons.cpp']]]
];
