var searchData=
[
  ['namecheck',['nameCheck',['../functions_8h.html#abce3c80460d71df3506f3acc3c65eabb',1,'nameCheck(string name, string &amp;countFalse, int i):&#160;functons.cpp'],['../functons_8cpp.html#abce3c80460d71df3506f3acc3c65eabb',1,'nameCheck(string name, string &amp;countFalse, int i):&#160;functons.cpp']]],
  ['numcheck',['numCheck',['../functions_8h.html#a3b22771c9078df6c9c26c2186bc0e0e9',1,'numCheck(string address, string &amp;countFalse):&#160;functons.cpp'],['../functons_8cpp.html#a3b22771c9078df6c9c26c2186bc0e0e9',1,'numCheck(string address, string &amp;countFalse):&#160;functons.cpp']]]
];
