var searchData=
[
  ['callsign',['callSign',['../struct_record.html#a6f7224685396af55043409034cb6a4d9',1,'Record']]],
  ['city',['city',['../struct_record.html#a3baf65b5ba42fc03e3b0223825c62108',1,'Record']]]
];
