var searchData=
[
  ['name',['name',['../struct_record.html#a92c06a66013646cc73579fc4aed1ba1d',1,'Record']]]
];
