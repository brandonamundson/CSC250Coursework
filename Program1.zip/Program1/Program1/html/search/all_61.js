var searchData=
[
  ['address',['address',['../struct_record.html#a4bbeaba8ed6af395828da8f830a48f88',1,'Record']]]
];
