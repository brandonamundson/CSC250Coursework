var searchData=
[
  ['licenseddate',['licensedDate',['../struct_record.html#acf42f233041d7e350eebff738ad44af6',1,'Record']]]
];
