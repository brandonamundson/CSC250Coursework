var searchData=
[
  ['openfiles',['openFiles',['../functions_8h.html#ab5886211a395cc42eabc4eab483784bf',1,'openFiles(ifstream &amp;fin, ofstream &amp;good, ofstream &amp;bad, char **commandline):&#160;functons.cpp'],['../functons_8cpp.html#ab5886211a395cc42eabc4eab483784bf',1,'openFiles(ifstream &amp;fin, ofstream &amp;good, ofstream &amp;bad, char **commandline):&#160;functons.cpp']]],
  ['outputerror',['outputError',['../functions_8h.html#af8fa96a0f0c56dcf8d66129e131aadca',1,'outputError(string &amp;countFalse, ofstream &amp;bad, Record record):&#160;functons.cpp'],['../functons_8cpp.html#af8fa96a0f0c56dcf8d66129e131aadca',1,'outputError(string &amp;countFalse, ofstream &amp;bad, Record record):&#160;functons.cpp']]],
  ['outputgood',['outputGood',['../functions_8h.html#aca185f7d586b8b47a332a98637622613',1,'outputGood(ofstream &amp;good, Record record):&#160;functons.cpp'],['../functons_8cpp.html#aca185f7d586b8b47a332a98637622613',1,'outputGood(ofstream &amp;good, Record record):&#160;functons.cpp']]]
];
