var searchData=
[
  ['expirationdate',['expirationDate',['../struct_record.html#add079d03e92fb4e5563176012a42b3d0',1,'Record']]]
];
