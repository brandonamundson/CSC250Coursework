var searchData=
[
  ['state',['state',['../struct_record.html#acfebf41340d22affb2ec1e90442e514f',1,'Record']]]
];
