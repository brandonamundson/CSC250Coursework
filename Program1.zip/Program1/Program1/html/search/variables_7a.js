var searchData=
[
  ['zipcode',['zipCode',['../struct_record.html#ab61b09ef938369ca04dfd57367363d9e',1,'Record']]]
];
